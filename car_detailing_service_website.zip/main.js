document.addEventListener('DOMContentLoaded', () => {
    // Add any event listeners or interactions here
});
